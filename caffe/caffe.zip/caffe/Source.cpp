#define _CRT_SECURE_NO_DEPRECATE

#define 	MAX_THREAD_NUMBER	1


#include <windows.h>
#include "Depth2Mesh.h"

#include "OPENGL_DRIVER.h"

int main(int argc, char *argv[]){

	OPENGL_DRIVER myDrive;

	//namedWindow("Display window1", WINDOW_AUTOSIZE);// Create a window for display.
	//imshow("Display window1", depth);                   // Show our image inside it.

	//waitKey(0);                                          // Wait for a keystroke in the window
	//system("Pause");
	return 0;
}