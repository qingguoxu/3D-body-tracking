#include "Depth2Mesh.h"


Mat depthmap2pointmap(Mat& depth){
	Mat1i U_temp, V_temp;
	int height = depth.rows;
	int width = depth.cols;
	 meshgridTest(Range(0.5,width - 0.5), Range(0.5 , height - 0.5),U_temp,V_temp);

	 Mat U, V;
	 Mat Z=depth;
	 U_temp.convertTo(U, CV_32FC1);
	 V_temp.convertTo(V, CV_32FC1);
	 cout << depth.type() << endl;
	 cout << U.type() << endl;
	 Mat Z_U=Z.mul(U);
	 Mat Z_V = Z.mul(V);
	 Mat KK_t = KK.t();
	 Mat output = Mat(Z.rows, Z.cols, CV_32FC3);
	 Mat temp=Mat(1,3,CV_32FC1);
	 for (int i = 0; i < Z.rows; i++)
	 {
		 for (int j = 0; j < Z.cols; j++)
		 {
			 temp.at<float>(0, 0) = Z_U.at<float>(i, j);
			 temp.at<float>(0, 1) = Z_V.at<float>(i, j);
			 temp.at<float>(0, 2) = Z.at<float>(i, j);
			// temp.val[0] = Z_U.at<float>(i, j);
			// temp.val[1] = Z_V.at<float>(i, j);
			// temp.val[2] = Z.at<float>(i, j);
			 Mat result = temp*KK_t.inv();
			 output.at<Vec3f>(i, j)[0] = result.at<Vec3f>(0, 0)[0];
			 output.at<Vec3f>(i, j)[1] = result.at<Vec3f>(0, 0)[1];
			 output.at<Vec3f>(i, j)[2] = result.at<Vec3f>(0, 0)[2];
			

		 }
	 }
	 return output;

}



 void meshgrid(const cv::Mat &xgv, const cv::Mat &ygv,
	cv::Mat1i &X, cv::Mat1i &Y)
{
	cv::repeat(xgv.reshape(1, 1), ygv.total(), 1, X);
	cv::repeat(ygv.reshape(1, 1).t(), 1, xgv.total(), Y);
}

 void meshgridG(const cv::Mat &xgv, const cv::Mat &ygv,
	 cv::Mat &X, cv::Mat &Y)
 {
	 cv::repeat(xgv.reshape(1, 1), ygv.total(), 1, X);
	 cv::repeat(ygv.reshape(1, 1).t(), 1, xgv.total(), Y);
 }

 static void meshgridTest(const cv::Range &xgv, const cv::Range &ygv,
	 cv::Mat1i &X, cv::Mat1i &Y)
 {
	 std::vector<int> t_x, t_y;
	 for (int i = xgv.start; i <= xgv.end; i++) t_x.push_back(i);
	 for (int i = ygv.start; i <= ygv.end; i++) t_y.push_back(i);
	 meshgrid(cv::Mat(t_x), cv::Mat(t_y), X, Y);
 }

 static void meshgridTestG(const cv::Range &xgv, const cv::Range &ygv,
	 cv::Mat &X, cv::Mat &Y)
 {
	 std::vector<int> t_x, t_y;
	 for (int i = xgv.start; i <= xgv.end; i++) t_x.push_back(i);
	 for (int i = ygv.start; i <= ygv.end; i++) t_y.push_back(i);
	 meshgridG(cv::Mat(t_x), cv::Mat(t_y), X, Y);
 }


 Mat im2bw(Mat src, double grayThresh)
 {
	 cv::Mat dst;
	 cv::threshold(src, dst, grayThresh, 255, CV_THRESH_BINARY);
	 return dst;
 }

 Mat MaskBlob(Mat& mask){

	 //keeps n biggest blobs in the mask
	 Mat output = mask.clone();
	 vector<vector<Point> > contours;
	 vector<Vec4i> hierarchy;
	 findContours(output, contours, hierarchy, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);



	 for (int idx = 0; idx < contours.size(); idx++)
	 {
		 if (contours[idx].size() > 30){
			 Scalar color(rand() & 255, rand() & 255, rand() & 255);
			 drawContours(output, contours, idx, color, CV_FILLED, 8, hierarchy);
		 }
	 }
 

	
	 return output;
 }


 void  selectmesh_vind(MESH<FLOAT_TYPE>& mesh, Mat& vind, int width, int height, MESH<FLOAT_TYPE>& submesh){

	 //MESH<FLOAT_TYPE> submesh;
	 int vnum = mesh.number;

	 vector<bool>validv(vnum,false);

	
	 for (int i = 0; i < vind.rows; i++)
	 {
		// cout << vind.at<Point>(i).x << endl;
		// cout << vind.at<Point>(i).y << endl;
		 int temp_ind = vind.at<Point>(i).x*height + vind.at<Point>(i).y;
		 validv[temp_ind] = true;
		// cout << validv[temp_ind] << endl;
	 }
	 
	 int subvnum = vind.rows;
	 vector<int> allind(vnum, 0);

	 for (int i = 0; i <subvnum; i++)
	 {

		 int temp_ind = vind.at<Point>(i).x*height + vind.at<Point>(i).y;
		 allind[temp_ind] = i;

	 }
 
   /////////////////////// step1 :determine if a triangle is valid

	 vector<Vec3i> subi;

	 for (int i = 0; i < mesh.t_number; i++)
	 {
		 if (validv[mesh.T[i * 3 + 0]] == true && validv[mesh.T[i * 3 + 1]] == true && validv[mesh.T[i * 3 + 2]] == true){
		    
			 Vec3i t;
			 t[0] = mesh.T[i * 3 + 0];
			 t[1] = mesh.T[i * 3 + 1];
			 t[2] = mesh.T[i * 3 + 2];
			 subi.push_back(t);
		 
		 }
	 }
	 // change the face index to new indices in vind


	 for (int i = 0; i < subi.size(); i++)
	 {
		 subi[i][0] = allind[subi[i][0]];
		 subi[i][1] = allind[subi[i][1]];
		 subi[i][2] = allind[subi[i][2]];
	 }



  /////////////////////// step2: determine if a vertex is referenced in the valid triangles

	 //is vertex from step1 an unreference point?, valid is the same size of vind

	 vector<bool> valid(subvnum, false);

	 for (int i = 0; i < subi.size(); i++)
	 {
		 valid[subi[i][0]] = true;
		 valid[subi[i][1]] = true;
		 valid[subi[i][2]] = true;
	 }

	 ///////////////////// compute the subv and its ind, ind2
	 int start_id = 0;
	 vector<int> ind;

	 vector<int> allind2(subvnum, 0);
	 for (int i = 0; i < valid.size(); i++)
	 {
		 if (valid[i] == true)
		 {
			 int temp_ind = vind.at<Point>(i).x*height + vind.at<Point>(i).y;
			 ind.push_back(temp_ind);
			 submesh.X[start_id * 3 + 0] = mesh.X[temp_ind * 3 + 0];
			 submesh.X[start_id * 3 + 1] = mesh.X[temp_ind * 3 + 1];
			 submesh.X[start_id * 3 + 2] = mesh.X[temp_ind * 3 + 2];
			 allind2[i] = start_id;
			 start_id++;
			
		 }

		

	 }
	 submesh.number = start_id;
	 ///////////////////// recompute the face index to new indices in subv
	 int subvnum_final = start_id;
	 
	
	 submesh.t_number = subi.size();
	 for (int i = 0; i < subi.size(); i++)
	 {
		
		
			// Vec3i t;
			/// subi[i][0] = allind2[subi[i][0]];
			// subi[i][1] = allind2[subi[i][1]];
			// subi[i][2] = allind2[subi[i][2]];
			 submesh.T[i * 3 + 0] = allind2[subi[i][0]];
			 submesh.T[i * 3 + 1] = allind2[subi[i][1]];
			 submesh.T[i * 3 + 2] = allind2[subi[i][2]];

		 
	 }

	 ///// recompute the texture coordinates, normals if needed
	 int vt_num = mesh.vt_number;
	 if (vt_num > 0)
	 {
		 for (int i = 0; i< vt_num; i++)
		 {
			 submesh.VT[i * 2 + 0] = mesh.VT[i * 2 + 0];
			 submesh.VT[i * 2 + 1] = mesh.VT[i * 2 + 2];
		 }

	 }
  
	// submesh.Write_OBJ("test2.obj");
	
	 //return submesh;
 
 }

 void pointmap2mesh(Mat& pointmap, Mat& mask, MESH<FLOAT_TYPE>& submesh){
    
	 MESH<FLOAT_TYPE>		mesh;
	 int m = pointmap.rows;//height
	 int n = pointmap.cols;//width

	 Mat channel[3];
	 split(pointmap, channel);

	 Mat channel_t[3];

	 channel_t[0] = channel[0].t();
	 channel_t[1] = channel[1].t();
	 channel_t[2] = channel[2].t();

	 Mat pointmap_permute;

	 merge(channel_t, 3, pointmap_permute);


	 Mat v = pointmap_permute.reshape(1, m*n);


	 Mat umap, vmap;

	 meshgridTestG(Range(0.5,n - 0.5), Range(0.5, m - 0.5), umap, vmap);

	 Mat channel_uv[2];

	 channel_uv[0] = umap.t();
	 channel_uv[1] = vmap.t();
	 Mat temp;
	 merge(channel_uv, 2, temp);

	 Mat uv = temp.reshape(1, m*n);
	 Mat vt = uv.clone();

	

	
	 for (int i = 0; i < vt.rows; i++)
	 {
		 vt.at<float>(i, 0) = vt.at<float>(i, 0) / n;
		 vt.at<float>(i, 1) = 1 - vt.at<float>(i, 1) / m;

	 }
 
	 // generate faces

	 Mat f = Mat::zeros((m - 1)*(n - 1)*2, 3,CV_32F);


	 for (int i = 1; i <= n - 1; i++)
	 {
		 for (int j = 1; j <=m - 1; j++)
		 {
			 int t1 = (i - 1)*m + j - 1;
			 int t2 = t1 + m;


			 f.at<float>((i - 1)*(m - 1) * 2 + (j - 1) * 2, 0) = t2;
			 f.at<float>((i - 1)*(m - 1) * 2 + (j - 1) * 2 + 1, 0) = t2 + 1;

			 f.at<float>((i - 1)*(m - 1) * 2 + (j - 1) * 2, 1) = t1;
			 f.at<float>((i - 1)*(m - 1) * 2 + (j - 1) * 2 + 1, 1) = t1;

			 f.at<float>((i - 1)*(m - 1) * 2 + (j - 1) * 2, 2) = t2 + 1;
			 f.at<float>((i - 1)*(m - 1) * 2 + (j - 1) * 2 + 1, 2) = t1 + 1;

			


		 }
	 }

	 // fill mesh

	 mesh.number = v.rows;
	 mesh.vt_number= v.rows;
	 mesh.t_number = f.rows;
	 for (int i = 0; i < mesh.number; i++)
	 {
		 mesh.X[i * 3 + 0] = v.at<float>(i, 0);
		 mesh.X[i * 3 + 1] = v.at<float>(i, 1);
		 mesh.X[i * 3 + 2] = v.at<float>(i, 2);



		 mesh.VT[i * 2 + 0] = vt.at<float>(i, 0);
		 mesh.VT[i * 2 + 1] = vt.at<float>(i, 1);
		 
	 }


	 for (int i = 0; i < mesh.t_number; i++)
	 {
		 mesh.T[i * 3 + 0] = f.at<float>(i, 0);
		 mesh.T[i * 3 + 1] = f.at<float>(i, 1);
		 mesh.T[i * 3 + 2] = f.at<float>(i, 2);


		

	 }

	

	 // extract the non zeros pixels in mask

	 Mat locations;
	 findNonZero(mask, locations);
	// MESH<FLOAT_TYPE> submesh;
	 if (locations.rows != v.rows){
	 
	 
		 selectmesh_vind(mesh, locations, n, m, submesh);
	 
	 
	 }



 }
